from flask import Flask
from database import create_db
from routes import api

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sim_cards.db'  # You can change to any database URI
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database
create_db(app)

# Register blueprints
app.register_blueprint(api)

if __name__ == '__main__':
    app.run(debug=True)
