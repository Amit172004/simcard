from flask import Blueprint, request, jsonify
from models import db, SIMCard
from datetime import datetime

api = Blueprint('api', __name__)

@api.route('/activate', methods=['POST'])
def activate_sim():
    data = request.json
    sim_number = data.get('sim_number')

    sim_card = SIMCard.query.get(sim_number)
    if not sim_card:
        return jsonify({'error': 'SIM card does not exist.'}), 404
    
    if sim_card.status == 'active':
        return jsonify({'error': 'SIM card is already active.'}), 400
    
    sim_card.status = 'active'
    sim_card.activation_date = datetime.now()
    db.session.commit()

    return jsonify({'message': 'SIM card activated successfully.'}), 200

@api.route('/deactivate', methods=['POST'])
def deactivate_sim():
    data = request.json
    sim_number = data.get('sim_number')

    sim_card = SIMCard.query.get(sim_number)
    if not sim_card:
        return jsonify({'error': 'SIM card does not exist.'}), 404
    
    if sim_card.status == 'inactive':
        return jsonify({'error': 'SIM card is already inactive.'}), 400
    
    sim_card.status = 'inactive'
    db.session.commit()

    return jsonify({'message': 'SIM card deactivated successfully.'}), 200

@api.route('/sim-details/<string:sim_number>', methods=['GET'])
def get_sim_details(sim_number):
    sim_card = SIMCard.query.get(sim_number)
    if not sim_card:
        return jsonify({'error': 'SIM card does not exist.'}), 404
    
    return jsonify({
        'sim_number': sim_card.sim_number,
        'phone_number': sim_card.phone_number,
        'status': sim_card.status,
        'activation_date': sim_card.activation_date
    }), 200
